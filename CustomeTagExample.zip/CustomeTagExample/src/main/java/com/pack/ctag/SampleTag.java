package com.pack.ctag;

import java.io.IOException;

import org.apache.jasper.el.JspELException;

import jakarta.servlet.jsp.JspWriter;
import jakarta.servlet.jsp.tagext.SimpleTagSupport;

public class SampleTag extends SimpleTagSupport{
	public void doTag() throws JspELException, IOException{
		
		JspWriter outobj=getJspContext().getOut();
		outobj.println("Hello inside Simple Custom Tag!!");
	}

}

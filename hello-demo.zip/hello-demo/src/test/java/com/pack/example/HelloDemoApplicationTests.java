package com.pack.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package org.springboot.springboot_jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}

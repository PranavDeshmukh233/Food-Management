package com.pack.spring.aspect;

public @interface Loggable {

}
